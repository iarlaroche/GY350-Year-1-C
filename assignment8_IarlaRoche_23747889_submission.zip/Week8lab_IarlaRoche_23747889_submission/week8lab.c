#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <string.h>

int main() {
    puts("Week 8 lab");
    char manufacture[5][80]{}; // An array of strings to store 5 inputted car manufacturer names, each with a maximum length of 80 characters.
    int len;//stores length of string
    char conversion = ' ';// this will store the characters from the array as upper case letters later on
    puts("Input 5 car manufacturers:");//tells user to input
    for (int i = 0; i < 5; i++) {//loops tghru each part of the array
        printf("Input car manufacturer %d: ", i + 1);
        gets_s(manufacture[i]);//stores input in i row
    }
    printf("\n");

    // Print the entered car manufacturers
    //puts("You entered these car manufacturers:");
    for (int i = 0; i < 5; i++) {
        //printf("Car manufacturer %d: %s\n", i + 1, manufacture[i]);
    }
    
    puts("Testing for CAPITAL letters\n____________\n");
    for (int i = 0; i < 5; i++) {
        len = strlen(manufacture[i]);//stores length of string in pos i in manufacture array
        //printf("TEST::Length of (%s) : %d \n", manufacture[i], len);// this is just a test
       
       
        for (int j = 0; j < len+1; j++) {
            if (isupper(manufacture[i][j])) {
                printf(" Uppercase letter found: %c\n", manufacture[i][j]);//checks if upper then prints  that its found if true
            }
      }
    }

    puts("\nFinal List\n__________\n");
    for (int i = 0; i < 5; i++) {
        len = strlen(manufacture[i]);//stores length of string in pos i in manufacture array
      
        for (int j = 0; j < len + 1; j++) {
            conversion = toupper(manufacture[i][j]);
            printf("%c", conversion);//prints each uppercase converted letter from the array acharacter by character
        }
        printf("\n");
    }
    //Next, search through each of the letters in each of the manufacturer names and check if the letter is uppercase.Print all uppercase letters to the screen
    
    return 0;
}
